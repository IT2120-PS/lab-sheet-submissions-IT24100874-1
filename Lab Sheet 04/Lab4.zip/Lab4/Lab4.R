#1
setwd("D:/Desktop/Lab4")
getwd()

branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")
fix(branch_data)
attach(branch_data)

#2
#Team - Categorical,Nominal scale
#Team Attendance - Numeric(Continuous), Ratio scale
#Team Salary - Numeric(Continuous), Ratio scale
#Years - Numeric(Continuous), Ratio scale

#3
boxplot(branch_data$Sales_X1, main="Boxplot for sales",ylab="Sales")

#4
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#5
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

find_outliers(branch_data$Years..X3.)
